from azure.recognizer import extraer_datos_cheque
from bcra.verificador import verificar_cheque_bcra
from utils.formatter import construir_json_respuesta
import sys

def main(ruta_pdf):
    datos_extraidos = extraer_datos_cheque(ruta_pdf)
    resultado_bcra = verificar_cheque_bcra(datos_extraidos['numero_cheque'], datos_extraidos['entidad_bancaria'])
    json_respuesta = construir_json_respuesta(datos_extraidos, resultado_bcra)
    print(json_respuesta)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python main.py <ruta_al_pdf>")
    else:
        main(sys.argv[1])
